# 使い方について
基本的にライセンスはありませんが、そのままコピーして公開するのはやめてください。コードを改造して公開したりするのは大歓迎です。
---
# 過去のアップデート
V1.0 初リリース！  
V1.1 エクスプローラーを開いたりできるようになった。自動アップデート（欠陥）が追加された。  
V1.2 不明  
V1.3 不明  
V1.4 不明  
V1.5 パスの指定ができるようになった。（当然だがな）  
V1.6 パスの指定方法がとてつもなく簡単になった。自動アップデート（欠陥）が削除され、ダウンロードかTyAppsDownLoaderをダウンロードするかを選べるようになった。READMEも大幅に変更された。

# 今後のアップデート
現在はV1.6ですが、今後も改良は続けていく予定です。モチベなどでしないかもしれませんがね。  
アプリにはアップデートを見つける機能がありますが今後のアプリ増加でわかりにくくなるかもしれないので[TyAppsDownLoader](https://github.com/BakedTaiyaki093/TyAppsDownloader)をダウンロードしてそこから管理することをおすすめします。
---
# URLs
[TyAppsDownLoader](https://github.com/BakedTaiyaki093/TyAppsDownloader)
[TyAppsLauncher](https://github.com/BakedTaiyaki093/TyAppsLauncher)
[Github:BakedTaiyaki093](https://github.com/BakedTaiyaki093)  
Created by [BakedTaiyaki093](https://github.com/BakedTaiyaki093)