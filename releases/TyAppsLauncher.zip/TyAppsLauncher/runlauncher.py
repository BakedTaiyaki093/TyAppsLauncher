import subprocess
import sys
import os

if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(__file__)

bat_path = os.path.join(base_dir, "launch.bat")

# 明示的にカレントディレクトリを指定して実行
command = (
    f'Start-Process cmd -WorkingDirectory "{base_dir}" '
    f'-ArgumentList \'/c "{bat_path}"\' -Verb RunAs'
)

subprocess.run(["powershell", "-Command", command])