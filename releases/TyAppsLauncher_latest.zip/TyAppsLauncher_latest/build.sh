#!/bin/bash

# ZIPファイル名を定義
ZIP_NAME="release/TyAppsLauncher_latest.zip"

# 必要なファイルをコピー
mkdir -p release/TyAppsLauncher_latest/assets
cp assets/taiyaki.ico release/TyAppsLauncher_latest/assets/taiyaki.ico
cp README.md release/TyAppsLauncher_latest/README.md
cp Version.txt release/TyAppsLauncher_latest/Version.txt
cp main.py release/TyAppsLauncher_latest/main.py

# ZIPの作成（古いZIPを削除して新しく作成）
rm -f $ZIP_NAME
zip -r $ZIP_NAME release/TyAppsLauncher_latest

echo "✅ ZIPファイルの更新完了: $ZIP_NAME"